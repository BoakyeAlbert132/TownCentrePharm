/**
 * Town Centre Pharmacy - Contact Controller
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

const ErrorResponse = require("../utils/errorResponse")
const asyncHandler = require("../middleware/async")
const sendEmail = require("../utils/sendEmail")
const Contact = require("../models/Contact") // Import the Contact model

// @desc    Send contact message
// @route   POST /api/contact
// @access  Public
exports.sendContactMessage = asyncHandler(async (req, res, next) => {
  const { name, email, phone, subject, message } = req.body

  // Validate required fields
  if (!name || !email || !phone || !subject || !message) {
    return next(new ErrorResponse("Please provide all required fields", 400))
  }

  try {
    // Send email to admin
    await sendEmail({
      email: process.env.FROM_EMAIL,
      subject: `Contact Form: ${subject}`,
      message: `
        You have received a new message from the contact form.
        
        Name: ${name}
        Email: ${email}
        Phone: ${phone}
        
        Message:
        ${message}
      `,
    })

    // Send confirmation email to user
    await sendEmail({
      email,
      subject: "Thank you for contacting Town Centre Pharmacy",
      message: `
        Dear ${name},
        
        Thank you for contacting Town Centre Pharmacy. We have received your message and will get back to you as soon as possible.
        
        Your message details:
        Subject: ${subject}
        
        Best regards,
        Town Centre Pharmacy Team
      `,
    })

    res.status(200).json({
      success: true,
      data: "Email sent",
    })
  } catch (err) {
    console.log(err)
    return next(new ErrorResponse("Email could not be sent", 500))
  }
})

// @desc    Get all contact messages
// @route   GET /api/contact
// @access  Private (Admin)
exports.getContactMessages = asyncHandler(async (req, res, next) => {
  // Copy req.query
  const reqQuery = { ...req.query }

  // Fields to exclude
  const removeFields = ["select", "sort", "page", "limit"]

  // Loop over removeFields and delete them from reqQuery
  removeFields.forEach((param) => delete reqQuery[param])

  // Create query string
  let queryStr = JSON.stringify(reqQuery)

  // Create operators ($gt, $gte, etc)
  queryStr = queryStr.replace(/\b(gt|gte|lt|lte|in)\b/g, (match) => `$${match}`)

  // Finding resource
  let query = Contact.find(JSON.parse(queryStr))

  // Select Fields
  if (req.query.select) {
    const fields = req.query.select.split(",").join(" ")
    query = query.select(fields)
  }

  // Sort
  if (req.query.sort) {
    const sortBy = req.query.sort.split(",").join(" ")
    query = query.sort(sortBy)
  } else {
    query = query.sort("-createdAt")
  }

  // Pagination
  const page = Number.parseInt(req.query.page, 10) || 1
  const limit = Number.parseInt(req.query.limit, 10) || 10
  const startIndex = (page - 1) * limit
  const endIndex = page * limit
  const total = await Contact.countDocuments(JSON.parse(queryStr))

  query = query.skip(startIndex).limit(limit)

  // Executing query
  const contacts = await query

  // Pagination result
  const pagination = {}

  if (endIndex < total) {
    pagination.next = {
      page: page + 1,
      limit,
    }
  }

  if (startIndex > 0) {
    pagination.prev = {
      page: page - 1,
      limit,
    }
  }

  res.status(200).json({
    success: true,
    count: contacts.length,
    pagination,
    data: contacts,
  })
})

// @desc    Get single contact message
// @route   GET /api/contact/:id
// @access  Private (Admin)
exports.getContactMessage = asyncHandler(async (req, res, next) => {
  const contact = await Contact.findById(req.params.id)

  if (!contact) {
    return next(new ErrorResponse(`Contact message not found with id of ${req.params.id}`, 404))
  }

  res.status(200).json({
    success: true,
    data: contact,
  })
})

// @desc    Update contact message
// @route   PUT /api/contact/:id
// @access  Private (Admin)
exports.updateContactMessage = asyncHandler(async (req, res, next) => {
  let contact = await Contact.findById(req.params.id)

  if (!contact) {
    return next(new ErrorResponse(`Contact message not found with id of ${req.params.id}`, 404))
  }

  contact = await Contact.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  })

  res.status(200).json({
    success: true,
    data: contact,
  })
})

// @desc    Delete contact message
// @route   DELETE /api/contact/:id
// @access  Private (Admin)
exports.deleteContactMessage = asyncHandler(async (req, res, next) => {
  const contact = await Contact.findById(req.params.id)

  if (!contact) {
    return next(new ErrorResponse(`Contact message not found with id of ${req.params.id}`, 404))
  }

  await contact.deleteOne()

  res.status(200).json({
    success: true,
    data: {},
  })
})
