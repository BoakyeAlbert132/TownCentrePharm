/**
 * Town Centre Pharmacy - Appointments Controller
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

const Appointment = require("../models/Appointment")
const ErrorResponse = require("../utils/errorResponse")
const asyncHandler = require("../middleware/async")
const sendEmail = require("../utils/sendEmail")

// @desc    Get all appointments
// @route   GET /api/appointments
// @access  Private (Admin)
exports.getAppointments = asyncHandler(async (req, res, next) => {
  // Copy req.query
  const reqQuery = { ...req.query }

  // Fields to exclude
  const removeFields = ["select", "sort", "page", "limit"]

  // Loop over removeFields and delete them from reqQuery
  removeFields.forEach((param) => delete reqQuery[param])

  // Create query string
  let queryStr = JSON.stringify(reqQuery)

  // Create operators ($gt, $gte, etc)
  queryStr = queryStr.replace(/\b(gt|gte|lt|lte|in)\b/g, (match) => `$${match}`)

  // Finding resource
  let query = Appointment.find(JSON.parse(queryStr)).populate({
    path: "user",
    select: "firstName lastName email phone",
  })

  // Select Fields
  if (req.query.select) {
    const fields = req.query.select.split(",").join(" ")
    query = query.select(fields)
  }

  // Sort
  if (req.query.sort) {
    const sortBy = req.query.sort.split(",").join(" ")
    query = query.sort(sortBy)
  } else {
    query = query.sort("-appointmentDate")
  }

  // Pagination
  const page = Number.parseInt(req.query.page, 10) || 1
  const limit = Number.parseInt(req.query.limit, 10) || 10
  const startIndex = (page - 1) * limit
  const endIndex = page * limit
  const total = await Appointment.countDocuments(JSON.parse(queryStr))

  query = query.skip(startIndex).limit(limit)

  // Executing query
  const appointments = await query

  // Pagination result
  const pagination = {}

  if (endIndex < total) {
    pagination.next = {
      page: page + 1,
      limit,
    }
  }

  if (startIndex > 0) {
    pagination.prev = {
      page: page - 1,
      limit,
    }
  }

  res.status(200).json({
    success: true,
    count: appointments.length,
    pagination,
    data: appointments,
  })
})

// @desc    Get single appointment
// @route   GET /api/appointments/:id
// @access  Private
exports.getAppointment = asyncHandler(async (req, res, next) => {
  const appointment = await Appointment.findById(req.params.id).populate({
    path: "user",
    select: "firstName lastName email phone",
  })

  if (!appointment) {
    return next(new ErrorResponse(`Appointment not found with id of ${req.params.id}`, 404))
  }

  // Make sure user is appointment owner or admin
  if (appointment.user && appointment.user._id.toString() !== req.user.id && req.user.role !== "admin") {
    return next(new ErrorResponse(`User ${req.user.id} is not authorized to view this appointment`, 401))
  }

  res.status(200).json({
    success: true,
    data: appointment,
  })
})

// @desc    Create new appointment
// @route   POST /api/appointments
// @access  Public
exports.createAppointment = asyncHandler(async (req, res, next) => {
  // If user is logged in, add user to req.body
  if (req.user) {
    req.body.user = req.user.id
  }

  // Check for existing appointments at the same time
  const existingAppointment = await Appointment.findOne({
    appointmentDate: new Date(req.body.appointmentDate),
    status: { $ne: "cancelled" },
  })

  if (existingAppointment) {
    return next(new ErrorResponse(`Appointment slot is already booked`, 400))
  }

  const appointment = await Appointment.create(req.body)

  // Send confirmation email
  try {
    await sendEmail({
      email: req.body.email,
      subject: "Appointment Confirmation",
      message: `
        Dear ${req.body.name},

        Thank you for booking an appointment with Town Centre Pharmacy.

        Your appointment details:
        Date: ${new Date(req.body.appointmentDate).toLocaleDateString()}
        Time: ${new Date(req.body.appointmentDate).toLocaleTimeString()}
        Service: ${req.body.service}

        If you need to reschedule or cancel your appointment, please contact us at least 24 hours in advance.

        Best regards,
        Town Centre Pharmacy Team
      `,
    })
  } catch (err) {
    console.log(err)
    // Don't return an error, just log it
  }

  res.status(201).json({
    success: true,
    data: appointment,
  })
})

// @desc    Update appointment
// @route   PUT /api/appointments/:id
// @access  Private (Admin)
exports.updateAppointment = asyncHandler(async (req, res, next) => {
  let appointment = await Appointment.findById(req.params.id)

  if (!appointment) {
    return next(new ErrorResponse(`Appointment not found with id of ${req.params.id}`, 404))
  }

  // If updating status to confirmed or rescheduled, send email
  if (req.body.status && (req.body.status === "confirmed" || req.body.status === "rescheduled")) {
    try {
      await sendEmail({
        email: appointment.email,
        subject: `Appointment ${req.body.status === "confirmed" ? "Confirmation" : "Rescheduled"}`,
        message: `
          Dear ${appointment.name},

          Your appointment with Town Centre Pharmacy has been ${req.body.status}.

          Appointment details:
          Date: ${new Date(appointment.appointmentDate).toLocaleDateString()}
          Time: ${new Date(appointment.appointmentDate).toLocaleTimeString()}
          Service: ${appointment.service}

          ${req.body.status === "rescheduled" ? "If the new time is not convenient, please contact us as soon as possible." : ""}

          Best regards,
          Town Centre Pharmacy Team
        `,
      })
    } catch (err) {
      console.log(err)
      // Don't return an error, just log it
    }
  }

  appointment = await Appointment.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  })

  res.status(200).json({
    success: true,
    data: appointment,
  })
})

// @desc    Delete appointment
// @route   DELETE /api/appointments/:id
// @access  Private (Admin)
exports.deleteAppointment = asyncHandler(async (req, res, next) => {
  const appointment = await Appointment.findById(req.params.id)

  if (!appointment) {
    return next(new ErrorResponse(`Appointment not found with id of ${req.params.id}`, 404))
  }

  await appointment.deleteOne()

  res.status(200).json({
    success: true,
    data: {},
  })
})

// @desc    Get logged in user appointments
// @route   GET /api/appointments/myappointments
// @access  Private
exports.getMyAppointments = asyncHandler(async (req, res, next) => {
  const appointments = await Appointment.find({ user: req.user.id })

  res.status(200).json({
    success: true,
    count: appointments.length,
    data: appointments,
  })
})
