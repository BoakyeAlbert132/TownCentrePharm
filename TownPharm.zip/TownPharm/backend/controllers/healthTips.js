/**
 * Town Centre Pharmacy - Health Tips Controller
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

const HealthTip = require("../models/HealthTip")
const ErrorResponse = require("../utils/errorResponse")
const asyncHandler = require("../middleware/async")
const path = require("path")
const fs = require("fs")

// @desc    Get all health tips
// @route   GET /api/healthtips
// @access  Public
exports.getHealthTips = asyncHandler(async (req, res, next) => {
  // Copy req.query
  const reqQuery = { ...req.query }

  // Fields to exclude
  const removeFields = ["select", "sort", "page", "limit", "search"]

  // Loop over removeFields and delete them from reqQuery
  removeFields.forEach((param) => delete reqQuery[param])

  // Create query string
  let queryStr = JSON.stringify(reqQuery)

  // Create operators ($gt, $gte, etc)
  queryStr = queryStr.replace(/\b(gt|gte|lt|lte|in)\b/g, (match) => `$${match}`)

  // Finding resource
  let query = HealthTip.find(JSON.parse(queryStr)).populate({
    path: "user",
    select: "firstName lastName",
  })

  // Search functionality
  if (req.query.search) {
    const searchRegex = new RegExp(req.query.search, "i")
    query = query.or([{ title: searchRegex }, { content: searchRegex }, { category: searchRegex }])
  }

  // Select Fields
  if (req.query.select) {
    const fields = req.query.select.split(",").join(" ")
    query = query.select(fields)
  }

  // Sort
  if (req.query.sort) {
    const sortBy = req.query.sort.split(",").join(" ")
    query = query.sort(sortBy)
  } else {
    query = query.sort("-createdAt")
  }

  // Pagination
  const page = Number.parseInt(req.query.page, 10) || 1
  const limit = Number.parseInt(req.query.limit, 10) || 10
  const startIndex = (page - 1) * limit
  const endIndex = page * limit
  const total = await HealthTip.countDocuments(JSON.parse(queryStr))

  query = query.skip(startIndex).limit(limit)

  // Executing query
  const healthTips = await query

  // Pagination result
  const pagination = {}

  if (endIndex < total) {
    pagination.next = {
      page: page + 1,
      limit,
    }
  }

  if (startIndex > 0) {
    pagination.prev = {
      page: page - 1,
      limit,
    }
  }

  res.status(200).json({
    success: true,
    count: healthTips.length,
    pagination,
    data: healthTips,
  })
})

// @desc    Get single health tip
// @route   GET /api/healthtips/:id
// @access  Public
exports.getHealthTip = asyncHandler(async (req, res, next) => {
  const healthTip = await HealthTip.findById(req.params.id).populate({
    path: "user",
    select: "firstName lastName",
  })

  if (!healthTip) {
    return next(new ErrorResponse(`Health tip not found with id of ${req.params.id}`, 404))
  }

  // Increment views
  healthTip.views = healthTip.views + 1
  await healthTip.save()

  res.status(200).json({
    success: true,
    data: healthTip,
  })
})

// @desc    Create new health tip
// @route   POST /api/healthtips
// @access  Private (Admin)
exports.createHealthTip = asyncHandler(async (req, res, next) => {
  // Add user to req.body
  req.body.user = req.user.id

  const healthTip = await HealthTip.create(req.body)

  res.status(201).json({
    success: true,
    data: healthTip,
  })
})

// @desc    Update health tip
// @route   PUT /api/healthtips/:id
// @access  Private (Admin)
exports.updateHealthTip = asyncHandler(async (req, res, next) => {
  let healthTip = await HealthTip.findById(req.params.id)

  if (!healthTip) {
    return next(new ErrorResponse(`Health tip not found with id of ${req.params.id}`, 404))
  }

  healthTip = await HealthTip.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  })

  res.status(200).json({
    success: true,
    data: healthTip,
  })
})

// @desc    Delete health tip
// @route   DELETE /api/healthtips/:id
// @access  Private (Admin)
exports.deleteHealthTip = asyncHandler(async (req, res, next) => {
  const healthTip = await HealthTip.findById(req.params.id)

  if (!healthTip) {
    return next(new ErrorResponse(`Health tip not found with id of ${req.params.id}`, 404))
  }

  await healthTip.deleteOne()

  res.status(200).json({
    success: true,
    data: {},
  })
})

// @desc    Upload health tip image
// @route   PUT /api/healthtips/:id/image
// @access  Private (Admin)
exports.uploadHealthTipImage = asyncHandler(async (req, res, next) => {
  const healthTip = await HealthTip.findById(req.params.id)

  if (!healthTip) {
    return next(new ErrorResponse(`Health tip not found with id of ${req.params.id}`, 404))
  }

  if (!req.files) {
    return next(new ErrorResponse(`Please upload a file`, 400))
  }

  const file = req.files.file

  // Make sure the image is a photo
  if (!file.mimetype.startsWith("image")) {
    return next(new ErrorResponse(`Please upload an image file`, 400))
  }

  // Check filesize
  if (file.size > process.env.MAX_FILE_UPLOAD || file.size > 1000000) {
    return next(new ErrorResponse(`Please upload an image less than 1MB`, 400))
  }

  // Create custom filename
  file.name = `health_tip_${healthTip._id}${path.parse(file.name).ext}`

  // Upload file
  file.mv(`${process.env.FILE_UPLOAD_PATH}/health-tips/${file.name}`, async (err) => {
    if (err) {
      console.error(err)
      return next(new ErrorResponse(`Problem with file upload`, 500))
    }

    // Update health tip with image
    await HealthTip.findByIdAndUpdate(req.params.id, { image: `/uploads/health-tips/${file.name}` })

    res.status(200).json({
      success: true,
      data: file.name,
    })
  })
})
