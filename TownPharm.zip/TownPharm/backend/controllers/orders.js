/**
 * Town Centre Pharmacy - Orders Controller
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

const Order = require("../models/Order")
const Product = require("../models/Product")
const ErrorResponse = require("../utils/errorResponse")
const asyncHandler = require("../middleware/async")

// @desc    Get all orders
// @route   GET /api/orders
// @access  Private (Admin)
exports.getOrders = asyncHandler(async (req, res, next) => {
  // Copy req.query
  const reqQuery = { ...req.query }

  // Fields to exclude
  const removeFields = ["select", "sort", "page", "limit"]

  // Loop over removeFields and delete them from reqQuery
  removeFields.forEach((param) => delete reqQuery[param])

  // Create query string
  let queryStr = JSON.stringify(reqQuery)

  // Create operators ($gt, $gte, etc)
  queryStr = queryStr.replace(/\b(gt|gte|lt|lte|in)\b/g, (match) => `$${match}`)

  // Finding resource
  let query = Order.find(JSON.parse(queryStr)).populate({
    path: "user",
    select: "firstName lastName email phone",
  })

  // Select Fields
  if (req.query.select) {
    const fields = req.query.select.split(",").join(" ")
    query = query.select(fields)
  }

  // Sort
  if (req.query.sort) {
    const sortBy = req.query.sort.split(",").join(" ")
    query = query.sort(sortBy)
  } else {
    query = query.sort("-createdAt")
  }

  // Pagination
  const page = Number.parseInt(req.query.page, 10) || 1
  const limit = Number.parseInt(req.query.limit, 10) || 10
  const startIndex = (page - 1) * limit
  const endIndex = page * limit
  const total = await Order.countDocuments(JSON.parse(queryStr))

  query = query.skip(startIndex).limit(limit)

  // Executing query
  const orders = await query

  // Pagination result
  const pagination = {}

  if (endIndex < total) {
    pagination.next = {
      page: page + 1,
      limit,
    }
  }

  if (startIndex > 0) {
    pagination.prev = {
      page: page - 1,
      limit,
    }
  }

  res.status(200).json({
    success: true,
    count: orders.length,
    pagination,
    data: orders,
  })
})

// @desc    Get single order
// @route   GET /api/orders/:id
// @access  Private
exports.getOrder = asyncHandler(async (req, res, next) => {
  const order = await Order.findById(req.params.id).populate({
    path: "user",
    select: "firstName lastName email phone",
  })

  if (!order) {
    return next(new ErrorResponse(`Order not found with id of ${req.params.id}`, 404))
  }

  // Make sure user is order owner or admin
  if (order.user.toString() !== req.user.id && req.user.role !== "admin") {
    return next(new ErrorResponse(`User ${req.user.id} is not authorized to view this order`, 401))
  }

  res.status(200).json({
    success: true,
    data: order,
  })
})

// @desc    Create new order
// @route   POST /api/orders
// @access  Private
exports.createOrder = asyncHandler(async (req, res, next) => {
  // Add user to req.body
  req.body.user = req.user.id

  // Check if order items exist and are in stock
  const orderItems = req.body.orderItems

  if (!orderItems || orderItems.length === 0) {
    return next(new ErrorResponse("No order items", 400))
  }

  // Verify products and calculate prices
  let totalPrice = 0

  for (let i = 0; i < orderItems.length; i++) {
    const item = orderItems[i]

    const product = await Product.findById(item.product)

    if (!product) {
      return next(new ErrorResponse(`Product not found with id of ${item.product}`, 404))
    }

    // Check if product is in stock
    if (!product.inStock) {
      return next(new ErrorResponse(`Product ${product.name} is out of stock`, 400))
    }

    // Set product price and name
    item.price = product.price
    item.name = product.name

    // Calculate total price
    totalPrice += item.price * item.quantity
  }

  // Calculate tax and shipping
  const taxPrice = totalPrice * 0.15
  const shippingPrice = totalPrice > 100 ? 0 : 10

  // Calculate final total
  const finalTotal = totalPrice + taxPrice + shippingPrice

  // Create order
  const order = await Order.create({
    orderItems,
    user: req.user.id,
    shippingAddress: req.body.shippingAddress,
    paymentMethod: req.body.paymentMethod,
    taxPrice,
    shippingPrice,
    totalPrice: finalTotal,
  })

  res.status(201).json({
    success: true,
    data: order,
  })
})

// @desc    Update order
// @route   PUT /api/orders/:id
// @access  Private (Admin)
exports.updateOrder = asyncHandler(async (req, res, next) => {
  let order = await Order.findById(req.params.id)

  if (!order) {
    return next(new ErrorResponse(`Order not found with id of ${req.params.id}`, 404))
  }

  order = await Order.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  })

  res.status(200).json({
    success: true,
    data: order,
  })
})

// @desc    Delete order
// @route   DELETE /api/orders/:id
// @access  Private (Admin)
exports.deleteOrder = asyncHandler(async (req, res, next) => {
  const order = await Order.findById(req.params.id)

  if (!order) {
    return next(new ErrorResponse(`Order not found with id of ${req.params.id}`, 404))
  }

  await order.deleteOne()

  res.status(200).json({
    success: true,
    data: {},
  })
})

// @desc    Get logged in user orders
// @route   GET /api/orders/myorders
// @access  Private
exports.getMyOrders = asyncHandler(async (req, res, next) => {
  const orders = await Order.find({ user: req.user.id })

  res.status(200).json({
    success: true,
    count: orders.length,
    data: orders,
  })
})

// @desc    Update order to paid
// @route   PUT /api/orders/:id/pay
// @access  Private
exports.updateOrderToPaid = asyncHandler(async (req, res, next) => {
  const order = await Order.findById(req.params.id)

  if (!order) {
    return next(new ErrorResponse(`Order not found with id of ${req.params.id}`, 404))
  }

  // Make sure user is order owner or admin
  if (order.user.toString() !== req.user.id && req.user.role !== "admin") {
    return next(new ErrorResponse(`User ${req.user.id} is not authorized to update this order`, 401))
  }

  order.isPaid = true
  order.paidAt = Date.now()
  order.paymentResult = {
    id: req.body.id,
    status: req.body.status,
    update_time: req.body.update_time,
    email_address: req.body.payer.email_address,
  }

  const updatedOrder = await order.save()

  res.status(200).json({
    success: true,
    data: updatedOrder,
  })
})

// @desc    Update order to delivered
// @route   PUT /api/orders/:id/deliver
// @access  Private (Admin)
exports.updateOrderToDelivered = asyncHandler(async (req, res, next) => {
  const order = await Order.findById(req.params.id)

  if (!order) {
    return next(new ErrorResponse(`Order not found with id of ${req.params.id}`, 404))
  }

  order.isDelivered = true
  order.deliveredAt = Date.now()

  const updatedOrder = await order.save()

  res.status(200).json({
    success: true,
    data: updatedOrder,
  })
})
