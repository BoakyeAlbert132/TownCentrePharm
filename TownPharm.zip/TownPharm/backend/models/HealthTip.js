/**
 * Town Centre Pharmacy - Health Tip Model
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

const mongoose = require("mongoose")

const HealthTipSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, "Please provide health tip title"],
    trim: true,
    maxlength: [100, "Title cannot be more than 100 characters"],
  },
  excerpt: {
    type: String,
    required: [true, "Please provide health tip excerpt"],
    maxlength: [200, "Excerpt cannot be more than 200 characters"],
  },
  content: {
    type: String,
    required: [true, "Please provide health tip content"],
  },
  category: {
    type: String,
    required: [true, "Please provide health tip category"],
    enum: ["general", "nutrition", "fitness", "mental-health", "medications", "chronic-conditions"],
  },
  image: {
    type: String,
    default: "no-image.jpg",
  },
  author: {
    type: String,
    required: [true, "Please provide author name"],
  },
  featured: {
    type: Boolean,
    default: false,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
})

// Create slug from title
HealthTipSchema.pre("save", function (next) {
  this.slug = this.title.toLowerCase().replace(/ /g, "-")
  next()
})

module.exports = mongoose.model("HealthTip", HealthTipSchema)
