/**
 * Town Centre Pharmacy - Appointment Model
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

const mongoose = require("mongoose")

const AppointmentSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
  name: {
    type: String,
    required: [true, "Please provide your name"],
    trim: true,
  },
  email: {
    type: String,
    required: [true, "Please provide your email"],
    match: [
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
      "Please provide a valid email",
    ],
  },
  phone: {
    type: String,
    required: [true, "Please provide your phone number"],
    trim: true,
  },
  consultationType: {
    type: String,
    required: [true, "Please select consultation type"],
    enum: ["in-person", "video"],
  },
  date: {
    type: Date,
    required: [true, "Please select appointment date"],
  },
  time: {
    type: String,
    required: [true, "Please select appointment time"],
  },
  reason: {
    type: String,
    required: [true, "Please provide reason for consultation"],
    maxlength: [500, "Reason cannot be more than 500 characters"],
  },
  medicalHistory: {
    type: String,
    maxlength: [1000, "Medical history cannot be more than 1000 characters"],
  },
  status: {
    type: String,
    enum: ["pending", "confirmed", "cancelled", "completed"],
    default: "pending",
  },
  notes: {
    type: String,
    maxlength: [1000, "Notes cannot be more than 1000 characters"],
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
})

module.exports = mongoose.model("Appointment", AppointmentSchema)
