/**
 * Town Centre Pharmacy - Product Model
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

const mongoose = require("mongoose")

const ProductSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Please provide product name"],
    trim: true,
    maxlength: [100, "Product name cannot be more than 100 characters"],
  },
  description: {
    type: String,
    required: [true, "Please provide product description"],
    maxlength: [500, "Description cannot be more than 500 characters"],
  },
  price: {
    type: Number,
    required: [true, "Please provide product price"],
    min: [0, "Price must be a positive number"],
  },
  category: {
    type: String,
    required: [true, "Please provide product category"],
    enum: ["orthodox", "herbal", "supplements", "personal-care"],
  },
  image: {
    type: String,
    default: "no-image.jpg",
  },
  inStock: {
    type: Boolean,
    default: true,
  },
  quantity: {
    type: Number,
    default: 0,
  },
  featured: {
    type: Boolean,
    default: false,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
})

// Create slug from name
ProductSchema.pre("save", function (next) {
  this.slug = this.name.toLowerCase().replace(/ /g, "-")
  next()
})

module.exports = mongoose.model("Product", ProductSchema)
