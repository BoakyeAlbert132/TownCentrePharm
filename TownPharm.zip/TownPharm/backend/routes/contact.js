/**
 * Town Centre Pharmacy - Contact Routes
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

const express = require("express")
const router = express.Router()
const {
  sendContactMessage,
  getContactMessages,
  getContactMessage,
  updateContactMessage,
  deleteContactMessage,
} = require("../controllers/contact")
const { protect, authorize } = require("../middleware/auth")

router.route("/").post(sendContactMessage).get(protect, authorize("admin"), getContactMessages)

router
  .route("/:id")
  .get(protect, authorize("admin"), getContactMessage)
  .put(protect, authorize("admin"), updateContactMessage)
  .delete(protect, authorize("admin"), deleteContactMessage)

module.exports = router
