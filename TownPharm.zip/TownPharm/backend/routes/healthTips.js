/**
 * Town Centre Pharmacy - Health Tip Routes
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

const express = require("express")
const router = express.Router()
const {
  getHealthTips,
  getHealthTip,
  createHealthTip,
  updateHealthTip,
  deleteHealthTip,
  uploadHealthTipImage,
} = require("../controllers/healthTips")
const { protect, authorize } = require("../middleware/auth")

router.route("/").get(getHealthTips).post(protect, authorize("admin"), createHealthTip)

router
  .route("/:id")
  .get(getHealthTip)
  .put(protect, authorize("admin"), updateHealthTip)
  .delete(protect, authorize("admin"), deleteHealthTip)

router.route("/:id/image").put(protect, authorize("admin"), uploadHealthTipImage)

module.exports = router
