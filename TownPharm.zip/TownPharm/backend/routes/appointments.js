/**
 * Town Centre Pharmacy - Appointment Routes
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

const express = require("express")
const router = express.Router()
const {
  getAppointments,
  getAppointment,
  createAppointment,
  updateAppointment,
  deleteAppointment,
  getMyAppointments,
} = require("../controllers/appointments")
const { protect, authorize } = require("../middleware/auth")

router.route("/").get(protect, authorize("admin"), getAppointments).post(createAppointment)

router.route("/myappointments").get(protect, getMyAppointments)

router
  .route("/:id")
  .get(protect, getAppointment)
  .put(protect, authorize("admin"), updateAppointment)
  .delete(protect, authorize("admin"), deleteAppointment)

module.exports = router
