/**
 * Town Centre Pharmacy - Database Seeder
 * Author: Town Centre Pharmacy
 * Version: 1.1
 */

const fs = require("fs")
const mongoose = require("mongoose")
const dotenv = require("dotenv")
const path = require("path")
const bcrypt = require("bcryptjs") // Add bcrypt for password hashing

// Load env vars
dotenv.config()

// Load models
const User = require("../models/User")
const Product = require("../models/Product")
const HealthTip = require("../models/HealthTip")

// Connect to DB
mongoose.connect(process.env.MONGODB_URI || "mongodb://localhost:27017/town-centre-pharmacy", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})

// Read JSON files
const users = JSON.parse(fs.readFileSync(path.join(__dirname, "_data", "users.json"), "utf-8"))
const products = JSON.parse(fs.readFileSync(path.join(__dirname, "_data", "products.json"), "utf-8"))
const healthTips = JSON.parse(fs.readFileSync(path.join(__dirname, "_data", "healthTips.json"), "utf-8"))

// Hash passwords before importing users
const hashUserPasswords = async (users) => {
  return await Promise.all(
    users.map(async (user) => {
      const salt = await bcrypt.genSalt(10)
      user.password = await bcrypt.hash(user.password, salt)
      return user
    })
  )
}

// Import into DB
const importData = async () => {
  try {
    const hashedUsers = await hashUserPasswords(users)
    await User.create(hashedUsers)
    await Product.create(products)
    await HealthTip.create(healthTips)

    console.log("✅ Data Imported Successfully")
    process.exit()
  } catch (err) {
    console.error("❌ Error importing data:", err)
    process.exit(1)
  }
}

// Delete data
const deleteData = async () => {
  try {
    await User.deleteMany()
    await Product.deleteMany()
    await HealthTip.deleteMany()

    console.log("🗑️ Data Destroyed Successfully")
    process.exit()
  } catch (err) {
    console.error("❌ Error deleting data:", err)
    process.exit(1)
  }
}

// CLI arguments
if (process.argv[2] === "-i") {
  importData()
} else if (process.argv[2] === "-d") {
  deleteData()
} else {
  console.log("⚠️  Please use -i to import or -d to delete")
  process.exit()
}
