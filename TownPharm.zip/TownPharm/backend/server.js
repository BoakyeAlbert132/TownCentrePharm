/**
 * Town Centre Pharmacy - Backend Server
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

// Import required modules
const express = require("express")
const mongoose = require("mongoose")
const cors = require("cors")
const path = require("path")
const dotenv = require("dotenv")
const morgan = require("morgan")
const fileupload = require("express-fileupload")
const cookieParser = require("cookie-parser")
const errorHandler = require("./middleware/error")

// Import routes
const authRoutes = require("./routes/auth")
const productRoutes = require("./routes/products")
const orderRoutes = require("./routes/orders")
const appointmentRoutes = require("./routes/appointments")
const userRoutes = require("./routes/users")
const healthTipRoutes = require("./routes/healthTips")
const contactRoutes = require("./routes/contact")

// Load environment variables
dotenv.config()

// Initialize Express app
const app = express()

// Set port
const PORT = process.env.PORT || 5000

// Middleware
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({ extended: false }))
app.use(cookieParser())
app.use(morgan("dev"))

// File uploading
app.use(fileupload())

// Set static folder
app.use(express.static(path.join(__dirname, "../frontend")))

// Create upload directories if they don't exist
const fs = require("fs")
const uploadDir = process.env.FILE_UPLOAD_PATH || "uploads"
const dirs = ["products", "health-tips", "profiles"]

if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir)
}

dirs.forEach((dir) => {
  const dirPath = path.join(uploadDir, dir)
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath)
  }
})

// API routes
app.use("/api/auth", authRoutes)
app.use("/api/products", productRoutes)
app.use("/api/orders", orderRoutes)
app.use("/api/appointments", appointmentRoutes)
app.use("/api/users", userRoutes)
app.use("/api/health-tips", healthTipRoutes)
app.use("/api/contact", contactRoutes)

// Serve uploads
app.use("/uploads", express.static(path.join(__dirname, "../uploads")))

// Serve frontend for any other routes
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/index.html"))
})

// Error handler middleware
app.use(errorHandler)

// Connect to MongoDB
mongoose
  .connect(process.env.MONGODB_URI || "mongodb://localhost:27017/town-centre-pharmacy", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("MongoDB connected successfully")

    // Start server
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`)
    })
  })
  .catch((err) => {
    console.error("MongoDB connection error:", err)
    process.exit(1)
  })

// Handle unhandled promise rejections
process.on("unhandledRejection", (err) => {
  console.error("Unhandled Promise Rejection:", err)
  // Close server & exit process
  process.exit(1)
})
