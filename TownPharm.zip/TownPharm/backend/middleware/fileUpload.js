/**
 * Town Centre Pharmacy - File Upload Middleware
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

const path = require("path")
const ErrorResponse = require("../utils/errorResponse")

// File upload middleware
exports.fileUpload = (req, res, next) => {
  // Check if files were uploaded
  if (!req.files) {
    return next()
  }

  const file = req.files.file

  // Make sure the file is an image
  if (!file.mimetype.startsWith("image")) {
    return next(new ErrorResponse(`Please upload an image file`, 400))
  }

  // Check file size
  if (file.size > process.env.MAX_FILE_UPLOAD) {
    return next(new ErrorResponse(`Please upload an image less than ${process.env.MAX_FILE_UPLOAD / 1000000}MB`, 400))
  }

  // Create custom filename
  file.name = `${req.filePrefix}_${Date.now()}${path.parse(file.name).ext}`

  // Upload file
  file.mv(`${process.env.FILE_UPLOAD_PATH}/${req.uploadPath}/${file.name}`, async (err) => {
    if (err) {
      console.error(err)
      return next(new ErrorResponse(`Problem with file upload`, 500))
    }

    req.fileName = file.name
    next()
  })
}
