/**
 * Town Centre Pharmacy - Main JavaScript
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

document.addEventListener("DOMContentLoaded", () => {
    // Initialize mobile menu
    initMobileMenu()
  
    // Initialize testimonial slider
    initTestimonialSlider()
  
    // Initialize FAQ accordions
    initFaqAccordions()
  
    // Initialize newsletter form
    initNewsletterForm()
  
    // Initialize scroll animations
    initScrollAnimations()
  })
  
  /**
   * Mobile Menu Functionality
   */
  function initMobileMenu() {
    const hamburger = document.querySelector(".hamburger")
    const body = document.body
  
    // Create mobile menu elements if they don't exist
    if (!document.querySelector(".mobile-menu")) {
      // Create overlay
      const overlay = document.createElement("div")
      overlay.className = "overlay"
  
      // Create mobile menu
      const mobileMenu = document.createElement("div")
      mobileMenu.className = "mobile-menu"
  
      // Create mobile menu header
      const mobileMenuHeader = document.createElement("div")
      mobileMenuHeader.className = "mobile-menu-header"
  
      const logoClone = document.querySelector(".logo").cloneNode(true)
  
      const closeBtn = document.createElement("button")
      closeBtn.className = "mobile-menu-close"
      closeBtn.innerHTML = '<i class="fas fa-times"></i>'
  
      mobileMenuHeader.appendChild(logoClone)
      mobileMenuHeader.appendChild(closeBtn)
  
      // Create mobile nav links
      const navLinksClone = document.querySelector(".nav-links").cloneNode(true)
      navLinksClone.className = "mobile-nav-links"
  
      // Create mobile auth buttons
      const authButtonsClone = document.querySelector(".auth-buttons").cloneNode(true)
      authButtonsClone.className = "mobile-auth-buttons"
  
      // Append all elements to mobile menu
      mobileMenu.appendChild(mobileMenuHeader)
      mobileMenu.appendChild(navLinksClone)
      mobileMenu.appendChild(authButtonsClone)
  
      // Append mobile menu and overlay to body
      body.appendChild(overlay)
      body.appendChild(mobileMenu)
  
      // Add event listeners for close button and overlay
      closeBtn.addEventListener("click", toggleMobileMenu)
      overlay.addEventListener("click", toggleMobileMenu)
    }
  
    // Toggle mobile menu on hamburger click
    if (hamburger) {
      hamburger.addEventListener("click", toggleMobileMenu)
    }
  
    // Function to toggle mobile menu
    function toggleMobileMenu() {
      const mobileMenu = document.querySelector(".mobile-menu")
      const overlay = document.querySelector(".overlay")
  
      if (mobileMenu.classList.contains("active")) {
        mobileMenu.classList.remove("active")
        overlay.classList.remove("active")
        body.style.overflow = ""
      } else {
        mobileMenu.classList.add("active")
        overlay.classList.add("active")
        body.style.overflow = "hidden"
      }
    }
  }
  
  /**
   * Testimonial Slider Functionality
   */
  function initTestimonialSlider() {
    const slider = document.querySelector(".testimonials-slider")
    const prevBtn = document.querySelector(".prev-btn")
    const nextBtn = document.querySelector(".next-btn")
  
    if (!slider || !prevBtn || !nextBtn) return
  
    const testimonials = slider.querySelectorAll(".testimonial-card")
    let currentIndex = 0
    let slideWidth = 0
    let slidesToShow = 3
  
    // Determine how many slides to show based on screen width
    function updateSlidesToShow() {
      if (window.innerWidth < 576) {
        slidesToShow = 1
      } else if (window.innerWidth < 992) {
        slidesToShow = 2
      } else {
        slidesToShow = 3
      }
  
      // Calculate slide width
      slideWidth = slider.offsetWidth / slidesToShow
  
      // Update testimonial card width
      testimonials.forEach((testimonial) => {
        testimonial.style.flex = `0 0 ${slideWidth}px`
      })
  
      // Reset slider position
      goToSlide(currentIndex)
    }
  
    // Go to specific slide
    function goToSlide(index) {
      if (index < 0) {
        index = 0
      } else if (index > testimonials.length - slidesToShow) {
        index = testimonials.length - slidesToShow
      }
  
      currentIndex = index
      slider.style.transform = `translateX(-${currentIndex * slideWidth}px)`
  
      // Update button states
      prevBtn.disabled = currentIndex === 0
      nextBtn.disabled = currentIndex >= testimonials.length - slidesToShow
    }
  
    // Event listeners for prev and next buttons
    prevBtn.addEventListener("click", () => {
      goToSlide(currentIndex - 1)
    })
  
    nextBtn.addEventListener("click", () => {
      goToSlide(currentIndex + 1)
    })
  
    // Update on window resize
    window.addEventListener("resize", updateSlidesToShow)
  
    // Initialize slider
    updateSlidesToShow()
  }
  
  /**
   * FAQ Accordions Functionality
   */
  function initFaqAccordions() {
    const faqItems = document.querySelectorAll(".faq-item")
  
    faqItems.forEach((item) => {
      const question = item.querySelector(".faq-question")
  
      question.addEventListener("click", () => {
        // Close all other FAQ items
        faqItems.forEach((otherItem) => {
          if (otherItem !== item && otherItem.classList.contains("active")) {
            otherItem.classList.remove("active")
          }
        })
  
        // Toggle current FAQ item
        item.classList.toggle("active")
      })
    })
  }
  
  /**
   * Newsletter Form Functionality
   */
  function initNewsletterForm() {
    const newsletterForm = document.getElementById("newsletter-form")
    const newsletterMessage = document.getElementById("newsletter-message")
  
    if (!newsletterForm || !newsletterMessage) return
  
    newsletterForm.addEventListener("submit", function (e) {
      e.preventDefault()
  
      const email = this.querySelector('input[type="email"]').value
  
      // Validate email
      if (!validateEmail(email)) {
        showMessage("Please enter a valid email address.", "error")
        return
      }
  
      // Simulate form submission
      showMessage("Submitting...", "info")
  
      // Simulate API call with timeout
      setTimeout(() => {
        // In a real application, you would send this data to your server
        console.log("Newsletter subscription:", email)
  
        // Show success message
        showMessage("Thank you for subscribing to our newsletter!", "success")
  
        // Reset form
        newsletterForm.reset()
      }, 1500)
    })
  
    // Function to show message
    function showMessage(text, type) {
      newsletterMessage.textContent = text
      newsletterMessage.className = `form-message ${type}`
      newsletterMessage.style.display = "block"
  
      // Hide message after 5 seconds for success messages
      if (type === "success") {
        setTimeout(() => {
          newsletterMessage.style.display = "none"
        }, 5000)
      }
    }
  
    // Function to validate email
    function validateEmail(email) {
      const re =
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      return re.test(String(email).toLowerCase())
    }
  }
  
  /**
   * Scroll Animations
   */
  function initScrollAnimations() {
    // Add fade-in animation to elements when they come into view
    const animateElements = document.querySelectorAll(
      ".service-card, .product-card, .testimonial-card, .feature-card, .team-card, .mv-card",
    )
  
    // Create intersection observer
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.style.opacity = "1"
            entry.target.style.transform = "translateY(0)"
            observer.unobserve(entry.target)
          }
        })
      },
      {
        threshold: 0.1,
      },
    )
  
    // Observe each element
    animateElements.forEach((element) => {
      // Set initial styles
      element.style.opacity = "0"
      element.style.transform = "translateY(20px)"
      element.style.transition = "opacity 0.5s ease, transform 0.5s ease"
  
      observer.observe(element)
    })
  
    // Smooth scroll for anchor links
    const anchorLinks = document.querySelectorAll('a[href^="#"]:not([href="#"])')
  
    anchorLinks.forEach((link) => {
      link.addEventListener("click", function (e) {
        e.preventDefault()
  
        const targetId = this.getAttribute("href")
        const targetElement = document.querySelector(targetId)
  
        if (targetElement) {
          window.scrollTo({
            top: targetElement.offsetTop - 100,
            behavior: "smooth",
          })
        }
      })
    })
  }
  
  /**
   * Utility Functions
   */
  
  // Format currency
  function formatCurrency(amount) {
    return "GH₵ " + Number.parseFloat(amount).toFixed(2)
  }
  
  // Format date
  function formatDate(dateString) {
    const options = { year: "numeric", month: "long", day: "numeric" }
    return new Date(dateString).toLocaleDateString("en-US", options)
  }
  
  // Get URL parameters
  function getUrlParams() {
    const params = {}
    const queryString = window.location.search.substring(1)
    const pairs = queryString.split("&")
  
    for (let i = 0; i < pairs.length; i++) {
      const pair = pairs[i].split("=")
      params[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1] || "")
    }
  
    return params
  }
  
  // Debounce function for search inputs
  function debounce(func, delay) {
    let timeout
  
    return function () {
      const args = arguments
  
      clearTimeout(timeout)
  
      timeout = setTimeout(() => {
        func.apply(this, args)
      }, delay)
    }
  }
  