/**
 * Town Centre Pharmacy - Products JavaScript
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

// Mock implementation for demonstration purposes. In a real application, this would be defined elsewhere.
function formatCurrency(number) {
    return "$" + number.toFixed(2)
  }
  
  // Mock implementation for demonstration purposes. In a real application, this would be defined elsewhere.
  function getUrlParams() {
    const params = {}
    const search = window.location.search.substring(1)
    if (search) {
      search.split("&").forEach((part) => {
        const item = part.split("=")
        params[item[0]] = decodeURIComponent(item[1])
      })
    }
    return params
  }
  
  document.addEventListener("DOMContentLoaded", () => {
    // Initialize product functionality
    initProducts()
  
    // Initialize product modal
    initProductModal()
  
    // Initialize shopping cart
    initShoppingCart()
  
    // Initialize product filters
    initProductFilters()
  
    // Initialize pagination
    initPagination()
  })
  
  // Sample product data (in a real application, this would come from a server)
  const productsData = [
    {
      id: 1,
      name: "Paracetamol 500mg",
      description: "Pain reliever and fever reducer for adults and children.",
      price: 15.0,
      category: "orthodox",
      image: "assets/images/product-1.jpg",
      inStock: true,
      featured: true,
    },
    {
      id: 2,
      name: "Vitamin C 1000mg",
      description: "Supports immune system health and overall wellness.",
      price: 25.0,
      category: "supplements",
      image: "assets/images/product-2.jpg",
      inStock: true,
      featured: true,
    },
    {
      id: 3,
      name: "Herbal Cough Syrup",
      description: "Natural remedy for cough and throat irritation.",
      price: 30.0,
      category: "herbal",
      image: "assets/images/product-3.jpg",
      inStock: true,
      featured: true,
    },
    {
      id: 4,
      name: "Blood Pressure Monitor",
      description: "Digital device for measuring blood pressure at home.",
      price: 150.0,
      category: "personal-care",
      image: "assets/images/product-4.jpg",
      inStock: true,
      featured: true,
    },
    {
      id: 5,
      name: "Amoxicillin 500mg",
      description: "Antibiotic used to treat a variety of bacterial infections.",
      price: 35.0,
      category: "orthodox",
      image: "assets/images/product-5.jpg",
      inStock: true,
      featured: false,
    },
    {
      id: 6,
      name: "Herbal Sleep Aid",
      description: "Natural supplement to improve sleep quality.",
      price: 28.0,
      category: "herbal",
      image: "assets/images/product-6.jpg",
      inStock: true,
      featured: false,
    },
    {
      id: 7,
      name: "Multivitamin Tablets",
      description: "Complete daily vitamin and mineral supplement.",
      price: 40.0,
      category: "supplements",
      image: "assets/images/product-7.jpg",
      inStock: true,
      featured: false,
    },
    {
      id: 8,
      name: "Hand Sanitizer",
      description: "Kills 99.9% of germs without water.",
      price: 12.0,
      category: "personal-care",
      image: "assets/images/product-8.jpg",
      inStock: true,
      featured: false,
    },
    {
      id: 9,
      name: "Ibuprofen 400mg",
      description: "Anti-inflammatory pain reliever for headaches and muscle pain.",
      price: 18.0,
      category: "orthodox",
      image: "assets/images/product-9.jpg",
      inStock: true,
      featured: false,
    },
    {
      id: 10,
      name: "Herbal Digestive Tea",
      description: "Soothes digestive discomfort and promotes gut health.",
      price: 22.0,
      category: "herbal",
      image: "assets/images/product-10.jpg",
      inStock: true,
      featured: false,
    },
    {
      id: 11,
      name: "Digital Thermometer",
      description: "Fast and accurate temperature readings.",
      price: 45.0,
      category: "personal-care",
      image: "assets/images/product-11.jpg",
      inStock: true,
      featured: false,
    },
    {
      id: 12,
      name: "Omega-3 Fish Oil",
      description: "Supports heart and brain health.",
      price: 35.0,
      category: "supplements",
      image: "assets/images/product-12.jpg",
      inStock: true,
      featured: false,
    },
  ]
  
  /**
   * Initialize Products
   */
  function initProducts() {
    const featuredProductsContainer = document.getElementById("featured-products-container")
    const productsContainer = document.getElementById("products-container")
  
    // Load featured products on home page
    if (featuredProductsContainer) {
      loadFeaturedProducts(featuredProductsContainer)
    }
  
    // Load all products on products page
    if (productsContainer) {
      loadProducts(productsContainer)
    }
  }
  
  /**
   * Load Featured Products
   */
  function loadFeaturedProducts(container) {
    // Clear skeleton loading placeholders
    container.innerHTML = ""
  
    // Filter featured products
    const featuredProducts = productsData.filter((product) => product.featured)
  
    // Render featured products
    featuredProducts.forEach((product) => {
      const productCard = createProductCard(product)
      container.appendChild(productCard)
    })
  }
  
  /**
   * Load All Products
   */
  function loadProducts(container, filters = {}) {
    // Clear skeleton loading placeholders
    container.innerHTML = ""
  
    // Filter products based on filters
    let filteredProducts = [...productsData]
  
    // Apply category filter
    if (filters.category && filters.category !== "all") {
      filteredProducts = filteredProducts.filter((product) => product.category === filters.category)
    }
  
    // Apply search filter
    if (filters.search) {
      const searchTerm = filters.search.toLowerCase()
      filteredProducts = filteredProducts.filter(
        (product) =>
          product.name.toLowerCase().includes(searchTerm) || product.description.toLowerCase().includes(searchTerm),
      )
    }
  
    // Apply sort filter
    if (filters.sort) {
      switch (filters.sort) {
        case "name-asc":
          filteredProducts.sort((a, b) => a.name.localeCompare(b.name))
          break
        case "name-desc":
          filteredProducts.sort((a, b) => b.name.localeCompare(a.name))
          break
        case "price-asc":
          filteredProducts.sort((a, b) => a.price - b.price)
          break
        case "price-desc":
          filteredProducts.sort((a, b) => b.price - a.price)
          break
      }
    }
  
    // Apply pagination
    const itemsPerPage = 8
    const currentPage = filters.page || 1
    const startIndex = (currentPage - 1) * itemsPerPage
    const paginatedProducts = filteredProducts.slice(startIndex, startIndex + itemsPerPage)
  
    // Update pagination
    updatePagination(filteredProducts.length, itemsPerPage, currentPage)
  
    // Render products
    if (paginatedProducts.length === 0) {
      container.innerHTML = `
              <div class="no-products">
                  <i class="fas fa-search"></i>
                  <h3>No products found</h3>
                  <p>Try adjusting your search or filter criteria.</p>
              </div>
          `
    } else {
      paginatedProducts.forEach((product) => {
        const productCard = createProductCard(product)
        container.appendChild(productCard)
      })
    }
  }
  
  /**
   * Create Product Card
   */
  function createProductCard(product) {
    const productCard = document.createElement("div")
    productCard.className = "product-card"
    productCard.dataset.id = product.id
  
    productCard.innerHTML = `
          <div class="product-image">
              <img src="${product.image}" alt="${product.name}">
          </div>
          <div class="product-info">
              <h3>${product.name}</h3>
              <p>${product.description}</p>
              <div class="product-price">${formatCurrency(product.price)}</div>
              <button class="btn btn-primary add-to-cart-btn" data-id="${product.id}">
                  <i class="fas fa-shopping-cart"></i> Add to Cart
              </button>
          </div>
      `
  
    // Add event listener to view product details
    productCard.querySelector(".product-image").addEventListener("click", () => {
      openProductModal(product)
    })
  
    productCard.querySelector("h3").addEventListener("click", () => {
      openProductModal(product)
    })
  
    // Add event listener to add to cart button
    productCard.querySelector(".add-to-cart-btn").addEventListener("click", (e) => {
      e.stopPropagation()
      addToCart(product)
    })
  
    return productCard
  }
  
  /**
   * Initialize Product Modal
   */
  function initProductModal() {
    const modal = document.getElementById("product-modal")
  
    if (!modal) return
  
    // Close modal when clicking on close button
    const closeBtn = modal.querySelector(".close-modal")
    closeBtn.addEventListener("click", closeProductModal)
  
    // Close modal when clicking outside the modal content
    modal.addEventListener("click", (e) => {
      if (e.target === modal) {
        closeProductModal()
      }
    })
  
    // Initialize quantity selector in modal
    const quantityInput = document.getElementById("product-quantity")
    const minusBtn = modal.querySelector(".quantity-btn.minus")
    const plusBtn = modal.querySelector(".quantity-btn.plus")
  
    if (quantityInput && minusBtn && plusBtn) {
      minusBtn.addEventListener("click", () => {
        const currentValue = Number.parseInt(quantityInput.value)
        if (currentValue > 1) {
          quantityInput.value = currentValue - 1
        }
      })
  
      plusBtn.addEventListener("click", () => {
        const currentValue = Number.parseInt(quantityInput.value)
        if (currentValue < 10) {
          quantityInput.value = currentValue + 1
        }
      })
  
      // Validate input to only allow numbers between 1 and 10
      quantityInput.addEventListener("input", () => {
        let value = Number.parseInt(quantityInput.value)
  
        if (isNaN(value) || value < 1) {
          value = 1
        } else if (value > 10) {
          value = 10
        }
  
        quantityInput.value = value
      })
    }
  
    // Add to cart from modal
    const addToCartBtn = document.getElementById("modal-add-to-cart")
  
    if (addToCartBtn) {
      addToCartBtn.addEventListener("click", () => {
        const productId = addToCartBtn.dataset.id
        const product = productsData.find((p) => p.id == productId)
  
        if (product) {
          const quantity = Number.parseInt(quantityInput.value)
          addToCart(product, quantity)
          closeProductModal()
        }
      })
    }
  }
  
  /**
   * Open Product Modal
   */
  function openProductModal(product) {
    const modal = document.getElementById("product-modal")
  
    if (!modal) return
  
    // Set product details in modal
    document.getElementById("modal-product-image").src = product.image
    document.getElementById("modal-product-name").textContent = product.name
    document.getElementById("modal-product-category").textContent = getCategoryName(product.category)
    document.getElementById("modal-product-price").textContent = formatCurrency(product.price)
    document.getElementById("modal-product-description").textContent = product.description
  
    // Reset quantity
    document.getElementById("product-quantity").value = 1
  
    // Set product ID for add to cart button
    document.getElementById("modal-add-to-cart").dataset.id = product.id
  
    // Show modal
    modal.style.display = "block"
    document.body.style.overflow = "hidden"
  }
  
  /**
   * Close Product Modal
   */
  function closeProductModal() {
    const modal = document.getElementById("product-modal")
  
    if (!modal) return
  
    modal.style.display = "none"
    document.body.style.overflow = ""
  }
  
  /**
   * Initialize Shopping Cart
   */
  function initShoppingCart() {
    // Get cart elements
    const cartToggle = document.getElementById("cart-toggle")
    const cartSidebar = document.getElementById("cart-sidebar")
    const closeCart = document.querySelector(".close-cart")
    const cartItems = document.getElementById("cart-items")
    const cartCount = document.getElementById("cart-count")
    const cartTotalAmount = document.getElementById("cart-total-amount")
    const checkoutBtn = document.getElementById("checkout-btn")
  
    if (!cartToggle || !cartSidebar) return
  
    // Initialize cart from localStorage
    let cart = JSON.parse(localStorage.getItem("cart")) || []
  
    // Update cart UI
    updateCartUI()
  
    // Toggle cart sidebar
    cartToggle.addEventListener("click", () => {
      cartSidebar.classList.toggle("open")
  
      if (cartSidebar.classList.contains("open")) {
        document.body.style.overflow = "hidden"
      } else {
        document.body.style.overflow = ""
      }
    })
  
    // Close cart
    closeCart.addEventListener("click", () => {
      cartSidebar.classList.remove("open")
      document.body.style.overflow = ""
    })
  
    // Checkout button
    if (checkoutBtn) {
      checkoutBtn.addEventListener("click", () => {
        if (cart.length === 0) {
          alert("Your cart is empty. Please add some products before checkout.")
          return
        }
  
        // In a real application, this would redirect to a checkout page
        alert("Proceeding to checkout...")
  
        // For demo purposes, clear the cart
        cart = []
        localStorage.setItem("cart", JSON.stringify(cart))
        updateCartUI()
  
        cartSidebar.classList.remove("open")
        document.body.style.overflow = ""
      })
    }
  
    /**
     * Add to Cart
     */
    window.addToCart = (product, quantity = 1) => {
      // Check if product is already in cart
      const existingItemIndex = cart.findIndex((item) => item.id === product.id)
  
      if (existingItemIndex !== -1) {
        // Update quantity if product is already in cart
        cart[existingItemIndex].quantity += quantity
      } else {
        // Add new product to cart
        cart.push({
          id: product.id,
          name: product.name,
          price: product.price,
          image: product.image,
          quantity: quantity,
        })
      }
  
      // Save cart to localStorage
      localStorage.setItem("cart", JSON.stringify(cart))
  
      // Update cart UI
      updateCartUI()
  
      // Show cart sidebar
      cartSidebar.classList.add("open")
      document.body.style.overflow = "hidden"
  
      // Show notification
      showNotification(`${product.name} added to cart!`)
    }
  
    /**
     * Update Cart UI
     */
    function updateCartUI() {
      // Update cart count
      cartCount.textContent = cart.reduce((total, item) => total + item.quantity, 0)
  
      // Update cart items
      if (cartItems) {
        if (cart.length === 0) {
          cartItems.innerHTML = `
                      <div class="empty-cart">
                          <i class="fas fa-shopping-basket"></i>
                          <p>Your cart is empty</p>
                          <a href="products.html" class="btn btn-outline">Start Shopping</a>
                      </div>
                  `
        } else {
          cartItems.innerHTML = ""
  
          cart.forEach((item) => {
            const cartItem = document.createElement("div")
            cartItem.className = "cart-item"
  
            cartItem.innerHTML = `
                          <div class="cart-item-image">
                              <img src="${item.image}" alt="${item.name}">
                          </div>
                          <div class="cart-item-info">
                              <h4>${item.name}</h4>
                              <div class="cart-item-price">${formatCurrency(item.price)}</div>
                              <div class="cart-item-quantity">
                                  <button class="decrease-quantity" data-id="${item.id}">-</button>
                                  <span>${item.quantity}</span>
                                  <button class="increase-quantity" data-id="${item.id}">+</button>
                              </div>
                          </div>
                          <button class="cart-item-remove" data-id="${item.id}">
                              <i class="fas fa-trash"></i>
                          </button>
                      `
  
            cartItems.appendChild(cartItem)
          })
  
          // Add event listeners to cart item buttons
          cartItems.querySelectorAll(".decrease-quantity").forEach((button) => {
            button.addEventListener("click", () => {
              const id = Number.parseInt(button.dataset.id)
              decreaseQuantity(id)
            })
          })
  
          cartItems.querySelectorAll(".increase-quantity").forEach((button) => {
            button.addEventListener("click", () => {
              const id = Number.parseInt(button.dataset.id)
              increaseQuantity(id)
            })
          })
  
          cartItems.querySelectorAll(".cart-item-remove").forEach((button) => {
            button.addEventListener("click", () => {
              const id = Number.parseInt(button.dataset.id)
              removeFromCart(id)
            })
          })
        }
      }
  
      // Update cart total
      if (cartTotalAmount) {
        const total = cart.reduce((total, item) => total + item.price * item.quantity, 0)
        cartTotalAmount.textContent = formatCurrency(total)
      }
    }
  
    /**
     * Decrease Quantity
     */
    function decreaseQuantity(id) {
      const itemIndex = cart.findIndex((item) => item.id === id)
  
      if (itemIndex !== -1) {
        if (cart[itemIndex].quantity > 1) {
          cart[itemIndex].quantity--
        } else {
          cart.splice(itemIndex, 1)
        }
  
        localStorage.setItem("cart", JSON.stringify(cart))
        updateCartUI()
      }
    }
  
    /**
     * Increase Quantity
     */
    function increaseQuantity(id) {
      const itemIndex = cart.findIndex((item) => item.id === id)
  
      if (itemIndex !== -1) {
        cart[itemIndex].quantity++
  
        localStorage.setItem("cart", JSON.stringify(cart))
        updateCartUI()
      }
    }
  
    /**
     * Remove from Cart
     */
    function removeFromCart(id) {
      const itemIndex = cart.findIndex((item) => item.id === id)
  
      if (itemIndex !== -1) {
        cart.splice(itemIndex, 1)
  
        localStorage.setItem("cart", JSON.stringify(cart))
        updateCartUI()
      }
    }
  }
  
  /**
   * Initialize Product Filters
   */
  function initProductFilters() {
    const productsContainer = document.getElementById("products-container")
    const searchInput = document.getElementById("product-search")
    const searchBtn = document.getElementById("search-btn")
    const categoryFilter = document.getElementById("category-filter")
    const sortBy = document.getElementById("sort-by")
    const categoryButtons = document.querySelectorAll(".category-btn")
  
    if (!productsContainer) return
  
    // Current filters
    const currentFilters = {
      category: "all",
      search: "",
      sort: "name-asc",
      page: 1,
    }
  
    // Apply filters and reload products
    function applyFilters() {
      loadProducts(productsContainer, currentFilters)
    }
  
    // Search functionality
    if (searchInput && searchBtn) {
      searchBtn.addEventListener("click", () => {
        currentFilters.search = searchInput.value
        currentFilters.page = 1
        applyFilters()
      })
  
      searchInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
          currentFilters.search = searchInput.value
          currentFilters.page = 1
          applyFilters()
        }
      })
    }
  
    // Category filter dropdown
    if (categoryFilter) {
      categoryFilter.addEventListener("change", () => {
        currentFilters.category = categoryFilter.value
        currentFilters.page = 1
        applyFilters()
  
        // Update category buttons
        categoryButtons.forEach((button) => {
          if (button.dataset.category === categoryFilter.value) {
            button.classList.add("active")
          } else {
            button.classList.remove("active")
          }
        })
      })
    }
  
    // Sort by dropdown
    if (sortBy) {
      sortBy.addEventListener("change", () => {
        currentFilters.sort = sortBy.value
        applyFilters()
      })
    }
  
    // Category buttons
    if (categoryButtons.length > 0) {
      categoryButtons.forEach((button) => {
        button.addEventListener("click", () => {
          const category = button.dataset.category
  
          // Update active button
          categoryButtons.forEach((btn) => btn.classList.remove("active"))
          button.classList.add("active")
  
          // Update category filter dropdown
          if (categoryFilter) {
            categoryFilter.value = category
          }
  
          // Apply filter
          currentFilters.category = category
          currentFilters.page = 1
          applyFilters()
        })
      })
    }
  
    // Check URL parameters for initial filters
    const urlParams = getUrlParams()
  
    if (urlParams.category) {
      currentFilters.category = urlParams.category
  
      // Update category filter dropdown
      if (categoryFilter) {
        categoryFilter.value = urlParams.category
      }
  
      // Update category buttons
      categoryButtons.forEach((button) => {
        if (button.dataset.category === urlParams.category) {
          button.classList.add("active")
        } else {
          button.classList.remove("active")
        }
      })
    }
  
    // Apply initial filters
    applyFilters()
  }
  
  /**
   * Initialize Pagination
   */
  function initPagination() {
    const pagination = document.getElementById("pagination")
    const prevPageBtn = document.getElementById("prev-page")
    const nextPageBtn = document.getElementById("next-page")
    const pageNumbers = document.getElementById("page-numbers")
  
    if (!pagination || !prevPageBtn || !nextPageBtn || !pageNumbers) return
  
    // Update pagination UI
    window.updatePagination = (totalItems, itemsPerPage, currentPage) => {
      const totalPages = Math.ceil(totalItems / itemsPerPage)
  
      // Update page numbers
      pageNumbers.innerHTML = ""
  
      // Determine which page numbers to show
      let startPage = Math.max(1, currentPage - 1)
      const endPage = Math.min(totalPages, startPage + 2)
  
      // Adjust if we're at the end
      if (endPage - startPage < 2) {
        startPage = Math.max(1, endPage - 2)
      }
  
      for (let i = startPage; i <= endPage; i++) {
        const pageBtn = document.createElement("button")
        pageBtn.className = `page-number ${i === currentPage ? "active" : ""}`
        pageBtn.textContent = i
  
        pageBtn.addEventListener("click", () => {
          goToPage(i)
        })
  
        pageNumbers.appendChild(pageBtn)
      }
  
      // Update prev/next buttons
      prevPageBtn.disabled = currentPage === 1
      nextPageBtn.disabled = currentPage === totalPages || totalPages === 0
  
      // Add event listeners to prev/next buttons
      prevPageBtn.onclick = () => {
        if (currentPage > 1) {
          goToPage(currentPage - 1)
        }
      }
  
      nextPageBtn.onclick = () => {
        if (currentPage < totalPages) {
          goToPage(currentPage + 1)
        }
      }
    }
  
    // Go to specific page
    function goToPage(page) {
      const productsContainer = document.getElementById("products-container")
  
      if (!productsContainer) return
  
      // Update current filters
      const currentFilters = {
        category: document.getElementById("category-filter")?.value || "all",
        search: document.getElementById("product-search")?.value || "",
        sort: document.getElementById("sort-by")?.value || "name-asc",
        page: page,
      }
  
      // Apply filters
      loadProducts(productsContainer, currentFilters)
  
      // Scroll to top of products section
      productsContainer.scrollIntoView({ behavior: "smooth" })
    }
  }
  
  /**
   * Show Notification
   */
  function showNotification(message) {
    // Create notification element if it doesn't exist
    let notification = document.querySelector(".notification")
  
    if (!notification) {
      notification = document.createElement("div")
      notification.className = "notification"
      document.body.appendChild(notification)
    }
  
    // Set message and show notification
    notification.textContent = message
    notification.classList.add("show")
  
    // Hide notification after 3 seconds
    setTimeout(() => {
      notification.classList.remove("show")
    }, 3000)
  }
  
  /**
   * Get Category Name
   */
  function getCategoryName(category) {
    const categories = {
      orthodox: "Orthodox Medicine",
      herbal: "Herbal Medicine",
      supplements: "Supplements",
      "personal-care": "Personal Care",
    }
  
    return categories[category] || category
  }
  