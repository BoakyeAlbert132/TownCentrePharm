/**
 * Town Centre Pharmacy - Health Tips JavaScript
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

document.addEventListener("DOMContentLoaded", () => {
    // Initialize health tips functionality
    initHealthTips()
  
    // Initialize question form
    initQuestionForm()
  })
  
  // Sample health tips data (in a real application, this would come from a server)
  const healthTipsData = [
    {
      id: 1,
      title: "The Importance of Regular Health Check-ups",
      excerpt: "Regular health check-ups are essential for maintaining good health and detecting potential issues early.",
      content:
        "Regular health check-ups are essential for maintaining good health and detecting potential issues early. In this article, we discuss why you should prioritize regular medical check-ups and what tests you should consider based on your age and health status.",
      category: "general",
      image: "assets/images/featured-health-tip.jpg",
      author: "Dr. Fordjour Peter",
      date: "2023-06-15",
      featured: true,
    },
    {
      id: 2,
      title: "Balanced Diet for a Healthy Heart",
      excerpt: "Learn about the foods that promote heart health and how to incorporate them into your daily diet.",
      content:
        "A balanced diet is crucial for maintaining a healthy heart. Foods rich in omega-3 fatty acids, fiber, antioxidants, and lean proteins can significantly reduce the risk of heart disease. This article explores heart-healthy foods and provides practical tips for incorporating them into your daily meals.",
      category: "nutrition",
      image: "assets/images/health-tip-1.jpg",
      author: "Sarah Owusu",
      date: "2023-06-10",
      featured: false,
    },
    {
      id: 3,
      title: "Simple Exercises for Busy Professionals",
      excerpt:
        "Discover quick and effective exercises that you can do even with a busy schedule to stay fit and healthy.",
      content:
        "Finding time for exercise can be challenging for busy professionals, but it's essential for maintaining good health. This article presents a series of quick, effective exercises that can be done in short breaks throughout the day, requiring minimal or no equipment.",
      category: "fitness",
      image: "assets/images/health-tip-2.jpg",
      author: "Michael Agyei",
      date: "2023-06-05",
      featured: false,
    },
    {
      id: 4,
      title: "Managing Stress in Daily Life",
      excerpt:
        "Practical tips and techniques to help you manage stress and maintain good mental health in today's fast-paced world.",
      content:
        "Chronic stress can have serious negative effects on both mental and physical health. This article provides practical strategies for managing stress, including mindfulness techniques, breathing exercises, physical activity, and lifestyle adjustments to help you maintain balance in your daily life.",
      category: "mental-health",
      image: "assets/images/health-tip-3.jpg",
      author: "Grace Mensah",
      date: "2023-05-28",
      featured: false,
    },
    {
      id: 5,
      title: "Understanding Antibiotics: Uses and Misuses",
      excerpt:
        "Learn about the proper use of antibiotics, common misconceptions, and the dangers of antibiotic resistance.",
      content:
        "Antibiotics are powerful medications used to treat bacterial infections, but their misuse has led to the growing problem of antibiotic resistance. This article explains how antibiotics work, when they should be used, common misconceptions, and the importance of following prescription guidelines to prevent resistance.",
      category: "medications",
      image: "assets/images/health-tip-4.jpg",
      author: "Dr. Fordjour Peter",
      date: "2023-05-20",
      featured: false,
    },
    {
      id: 6,
      title: "The Importance of Hydration",
      excerpt:
        "Discover why staying hydrated is crucial for your health and learn practical tips to ensure you drink enough water daily.",
      content:
        "Water is essential for nearly every bodily function, from regulating temperature to supporting digestion and nutrient absorption. This article explains the importance of proper hydration, signs of dehydration, and practical strategies to ensure you're drinking enough water throughout the day.",
      category: "general",
      image: "assets/images/health-tip-5.jpg",
      author: "Sarah Owusu",
      date: "2023-05-15",
      featured: false,
    },
    {
      id: 7,
      title: "Superfoods for Immune System Boost",
      excerpt: "Explore the power of superfoods that can help strengthen your immune system and keep illnesses at bay.",
      content:
        'Certain foods are particularly rich in nutrients that support immune function. This article highlights these "superfoods," explaining their specific benefits and offering suggestions for incorporating them into your diet to help strengthen your body\'s natural defenses against illness.',
      category: "nutrition",
      image: "assets/images/health-tip-6.jpg",
      author: "Michael Agyei",
      date: "2023-05-08",
      featured: false,
    },
  ]
  
  /**
   * Get URL Parameters
   */
  function getUrlParams() {
    const params = {}
    const search = window.location.search.substring(1)
    if (search) {
      search.split("&").forEach((item) => {
        const parts = item.split("=")
        params[parts[0]] = decodeURIComponent(parts[1])
      })
    }
    return params
  }
  
  /**
   * Initialize Health Tips
   */
  function initHealthTips() {
    const articlesContainer = document.getElementById("articles-container")
    const blogSearch = document.getElementById("blog-search")
    const searchBtn = document.getElementById("search-btn")
    const categoryButtons = document.querySelectorAll(".category-btn")
  
    if (!articlesContainer) return
  
    // Load health tips
    loadHealthTips(articlesContainer)
  
    // Search functionality
    if (blogSearch && searchBtn) {
      searchBtn.addEventListener("click", () => {
        const searchTerm = blogSearch.value.toLowerCase()
        filterHealthTips(articlesContainer, searchTerm, getCurrentCategory())
      })
  
      blogSearch.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
          const searchTerm = blogSearch.value.toLowerCase()
          filterHealthTips(articlesContainer, searchTerm, getCurrentCategory())
        }
      })
    }
  
    // Category filter
    if (categoryButtons.length > 0) {
      categoryButtons.forEach((button) => {
        button.addEventListener("click", () => {
          // Update active button
          categoryButtons.forEach((btn) => btn.classList.remove("active"))
          button.classList.add("active")
  
          // Filter health tips
          const category = button.dataset.category
          const searchTerm = blogSearch ? blogSearch.value.toLowerCase() : ""
          filterHealthTips(articlesContainer, searchTerm, category)
        })
      })
    }
  
    // Check URL parameters for initial filters
    const urlParams = getUrlParams()
  
    if (urlParams.category) {
      // Update active button
      categoryButtons.forEach((button) => {
        if (button.dataset.category === urlParams.category) {
          button.classList.add("active")
        } else {
          button.classList.remove("active")
        }
      })
  
      // Filter health tips
      filterHealthTips(articlesContainer, "", urlParams.category)
    }
  }
  
  /**
   * Load Health Tips
   */
  function loadHealthTips(container, searchTerm = "", category = "all") {
    // Filter health tips
    let filteredTips = [...healthTipsData]
  
    // Apply category filter
    if (category && category !== "all") {
      filteredTips = filteredTips.filter((tip) => tip.category === category)
    }
  
    // Apply search filter
    if (searchTerm) {
      filteredTips = filteredTips.filter(
        (tip) =>
          tip.title.toLowerCase().includes(searchTerm) ||
          tip.excerpt.toLowerCase().includes(searchTerm) ||
          tip.content.toLowerCase().includes(searchTerm),
      )
    }
  
    // Clear container
    container.innerHTML = ""
  
    // Render health tips
    if (filteredTips.length === 0) {
      container.innerHTML = `
              <div class="no-articles">
                  <i class="fas fa-search"></i>
                  <h3>No health tips found</h3>
                  <p>Try adjusting your search or filter criteria.</p>
              </div>
          `
    } else {
      filteredTips.forEach((tip) => {
        const articleCard = createArticleCard(tip)
        container.appendChild(articleCard)
      })
    }
  }
  
  /**
   * Filter Health Tips
   */
  function filterHealthTips(container, searchTerm = "", category = "all") {
    loadHealthTips(container, searchTerm, category)
  }
  
  /**
   * Create Article Card
   */
  function createArticleCard(article) {
    const articleCard = document.createElement("div")
    articleCard.className = "article-card"
  
    articleCard.innerHTML = `
          <div class="article-image">
              <img src="${article.image}" alt="${article.title}">
              <div class="article-category">${getCategoryName(article.category)}</div>
          </div>
          <div class="article-content">
              <div class="article-meta">
                  <span class="article-date"><i class="far fa-calendar-alt"></i> ${formatDate(article.date)}</span>
              </div>
              <h3>${article.title}</h3>
              <p>${article.excerpt}</p>
              <a href="health-tip.html?id=${article.id}" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
          </div>
      `
  
    return articleCard
  }
  
  /**
   * Get Current Category
   */
  function getCurrentCategory() {
    const activeButton = document.querySelector(".category-btn.active")
    return activeButton ? activeButton.dataset.category : "all"
  }
  
  /**
   * Get Category Name
   */
  function getCategoryName(category) {
    const categories = {
      general: "General Health",
      nutrition: "Nutrition",
      fitness: "Fitness",
      "mental-health": "Mental Health",
      medications: "Medications",
      "chronic-conditions": "Chronic Conditions",
    }
  
    return categories[category] || category
  }
  
  /**
   * Initialize Question Form
   */
  function initQuestionForm() {
    const questionForm = document.getElementById("question-form")
    const questionMessage = document.getElementById("question-message")
  
    if (!questionForm || !questionMessage) return
  
    questionForm.addEventListener("submit", function (e) {
      e.preventDefault()
  
      // Get form data
      const name = this.querySelector("#question-name").value
      const email = this.querySelector("#question-email").value
      const question = this.querySelector("#question-text").value
      const isPublic = this.querySelector("#question-public")?.checked || false
  
      // Validate form data
      if (!name || !email || !question) {
        showMessage(questionMessage, "Please fill in all required fields.", "error")
        return
      }
  
      if (!validateEmail(email)) {
        showMessage(questionMessage, "Please enter a valid email address.", "error")
        return
      }
  
      // Show loading message
      showMessage(questionMessage, "Submitting your question...", "info")
  
      // Simulate API call with timeout
      setTimeout(() => {
        // In a real application, you would send this data to your server
        console.log("Health question:", { name, email, question, isPublic })
  
        // Show success message
        showMessage(
          questionMessage,
          "Your question has been submitted successfully! Our healthcare professionals will respond to you via email.",
          "success",
        )
  
        // Reset form
        questionForm.reset()
      }, 1500)
    })
  }
  
  /**
   * Show Message
   */
  function showMessage(element, text, type) {
    element.textContent = text
    element.className = `form-message ${type}`
    element.style.display = "block"
  
    // Scroll to message
    element.scrollIntoView({ behavior: "smooth", block: "center" })
  
    // Hide message after 5 seconds for success messages
    if (type === "success") {
      setTimeout(() => {
        element.style.display = "none"
      }, 5000)
    }
  }
  
  /**
   * Validate Email
   */
  function validateEmail(email) {
    const re =
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    return re.test(String(email).toLowerCase())
  }
  
  /**
   * Format Date
   */
  function formatDate(dateString) {
    const options = { year: "numeric", month: "long", day: "numeric" }
    return new Date(dateString).toLocaleDateString("en-US", options)
  }
  