/**
 * Town Centre Pharmacy - Contact JavaScript
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

document.addEventListener("DOMContentLoaded", () => {
    // Initialize contact form
    initContactForm()
  })
  
  /**
   * Initialize Contact Form
   */
  function initContactForm() {
    const contactForm = document.getElementById("contact-form")
    const contactMessage = document.getElementById("contact-message")
  
    if (!contactForm || !contactMessage) return
  
    contactForm.addEventListener("submit", function (e) {
      e.preventDefault()
  
      // Get form data
      const name = this.querySelector("#name").value
      const email = this.querySelector("#email").value
      const phone = this.querySelector("#phone").value
      const subject = this.querySelector("#subject").value
      const message = this.querySelector("#message").value
  
      // Validate form data
      if (!name || !email || !phone || !subject || !message) {
        showMessage(contactMessage, "Please fill in all required fields.", "error")
        return
      }
  
      if (!validateEmail(email)) {
        showMessage(contactMessage, "Please enter a valid email address.", "error")
        return
      }
  
      if (!validatePhone(phone)) {
        showMessage(contactMessage, "Please enter a valid phone number.", "error")
        return
      }
  
      // Show loading message
      showMessage(contactMessage, "Sending your message...", "info")
  
      // Simulate API call with timeout
      setTimeout(() => {
        // In a real application, you would send this data to your server
        console.log("Contact form:", { name, email, phone, subject, message })
  
        // Show success message
        showMessage(
          contactMessage,
          "Your message has been sent successfully! We will get back to you as soon as possible.",
          "success",
        )
  
        // Reset form
        contactForm.reset()
      }, 1500)
    })
  }
  
  /**
   * Show Message
   */
  function showMessage(element, text, type) {
    element.textContent = text
    element.className = `form-message ${type}`
    element.style.display = "block"
  
    // Scroll to message
    element.scrollIntoView({ behavior: "smooth", block: "center" })
  
    // Hide message after 5 seconds for success messages
    if (type === "success") {
      setTimeout(() => {
        element.style.display = "none"
      }, 5000)
    }
  }
  
  /**
   * Validate Email
   */
  function validateEmail(email) {
    const re =
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    return re.test(String(email).toLowerCase())
  }
  
  /**
   * Validate Phone
   */
  function validatePhone(phone) {
    // Simple validation for demo purposes
    // In a real application, you would use a more robust validation
    return phone.length >= 10
  }
  