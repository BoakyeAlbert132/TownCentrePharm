/**
 * Town Centre Pharmacy - Authentication JavaScript
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

document.addEventListener("DOMContentLoaded", () => {
    // Initialize login form
    initLoginForm()
  
    // Initialize register form
    initRegisterForm()
  
    // Initialize password toggle
    initPasswordToggle()
  
    // Initialize password strength meter
    initPasswordStrengthMeter()
  })
  
  /**
   * Initialize Login Form
   */
  function initLoginForm() {
    const loginForm = document.getElementById("login-form")
    const loginMessage = document.getElementById("login-message")
  
    if (!loginForm || !loginMessage) return
  
    loginForm.addEventListener("submit", function (e) {
      e.preventDefault()
  
      // Get form data
      const email = this.querySelector("#email").value
      const password = this.querySelector("#password").value
      const remember = this.querySelector("#remember")?.checked || false
  
      // Validate form data
      if (!validateEmail(email)) {
        showMessage(loginMessage, "Please enter a valid email address.", "error")
        return
      }
  
      if (password.length < 6) {
        showMessage(loginMessage, "Password must be at least 6 characters.", "error")
        return
      }
  
      // Show loading message
      showMessage(loginMessage, "Logging in...", "info")
  
      // Simulate API call with timeout
      setTimeout(() => {
        // In a real application, you would send this data to your server
        console.log("Login attempt:", { email, password, remember })
  
        // For demo purposes, check if email is admin@example.com and password is admin123
        if (email === "admin@example.com" && password === "admin123") {
          // Admin login
          showMessage(loginMessage, "Login successful! Redirecting to admin dashboard...", "success")
  
          // Redirect to admin dashboard after 1 second
          setTimeout(() => {
            window.location.href = "admin/dashboard.html"
          }, 1000)
        } else if (email === "user@example.com" && password === "user123") {
          // User login
          showMessage(loginMessage, "Login successful! Redirecting...", "success")
  
          // Redirect to home page after 1 second
          setTimeout(() => {
            window.location.href = "index.html"
          }, 1000)
        } else {
          // Invalid credentials
          showMessage(loginMessage, "Invalid email or password. Please try again.", "error")
        }
      }, 1500)
    })
  }
  
  /**
   * Initialize Register Form
   */
  function initRegisterForm() {
    const registerForm = document.getElementById("register-form")
    const registerMessage = document.getElementById("register-message")
  
    if (!registerForm || !registerMessage) return
  
    registerForm.addEventListener("submit", function (e) {
      e.preventDefault()
  
      // Get form data
      const firstName = this.querySelector("#first-name").value
      const lastName = this.querySelector("#last-name").value
      const email = this.querySelector("#email").value
      const phone = this.querySelector("#phone").value
      const password = this.querySelector("#password").value
      const confirmPassword = this.querySelector("#confirm-password").value
      const terms = this.querySelector("#terms")?.checked || false
  
      // Validate form data
      if (!firstName || !lastName) {
        showMessage(registerMessage, "Please enter your full name.", "error")
        return
      }
  
      if (!validateEmail(email)) {
        showMessage(registerMessage, "Please enter a valid email address.", "error")
        return
      }
  
      if (!validatePhone(phone)) {
        showMessage(registerMessage, "Please enter a valid phone number.", "error")
        return
      }
  
      if (password.length < 6) {
        showMessage(registerMessage, "Password must be at least 6 characters.", "error")
        return
      }
  
      if (password !== confirmPassword) {
        showMessage(registerMessage, "Passwords do not match.", "error")
        return
      }
  
      if (!terms) {
        showMessage(registerMessage, "Please agree to the Terms and Conditions.", "error")
        return
      }
  
      // Show loading message
      showMessage(registerMessage, "Creating your account...", "info")
  
      // Simulate API call with timeout
      setTimeout(() => {
        // In a real application, you would send this data to your server
        console.log("Registration:", { firstName, lastName, email, phone, password, terms })
  
        // Show success message
        showMessage(registerMessage, "Registration successful! Redirecting to login page...", "success")
  
        // Redirect to login page after 2 seconds
        setTimeout(() => {
          window.location.href = "login.html"
        }, 2000)
      }, 1500)
    })
  }
  
  /**
   * Initialize Password Toggle
   */
  function initPasswordToggle() {
    const toggleButtons = document.querySelectorAll(".toggle-password")
  
    toggleButtons.forEach((button) => {
      button.addEventListener("click", function () {
        const input = this.parentElement.querySelector("input")
        const icon = this.querySelector("i")
  
        if (input.type === "password") {
          input.type = "text"
          icon.classList.remove("fa-eye")
          icon.classList.add("fa-eye-slash")
        } else {
          input.type = "password"
          icon.classList.remove("fa-eye-slash")
          icon.classList.add("fa-eye")
        }
      })
    })
  }
  
  /**
   * Initialize Password Strength Meter
   */
  function initPasswordStrengthMeter() {
    const passwordInput = document.getElementById("password")
    const strengthBar = document.querySelector(".strength-bar")
    const strengthText = document.querySelector(".strength-text")
  
    if (!passwordInput || !strengthBar || !strengthText) return
  
    passwordInput.addEventListener("input", function () {
      const password = this.value
      const strength = calculatePasswordStrength(password)
  
      // Update strength bar
      strengthBar.style.width = `${strength.score * 25}%`
  
      // Update strength class
      strengthBar.className = "strength-bar"
      if (strength.score > 0) {
        strengthBar.classList.add(strength.level)
      }
  
      // Update strength text
      strengthText.textContent = `Password strength: ${strength.level}`
    })
  }
  
  /**
   * Calculate Password Strength
   */
  function calculatePasswordStrength(password) {
    // Initialize score
    let score = 0
  
    // Return early if password is empty
    if (!password) {
      return { score: 0, level: "weak" }
    }
  
    // Add points for length
    if (password.length >= 8) {
      score += 1
    }
  
    // Add points for complexity
    if (/[A-Z]/.test(password)) {
      score += 1
    }
  
    if (/[0-9]/.test(password)) {
      score += 1
    }
  
    if (/[^A-Za-z0-9]/.test(password)) {
      score += 1
    }
  
    // Determine strength level
    let level = "weak"
  
    if (score === 4) {
      level = "strong"
    } else if (score >= 2) {
      level = "medium"
    }
  
    return { score, level }
  }
  
  /**
   * Show Message
   */
  function showMessage(element, text, type) {
    element.textContent = text
    element.className = `form-message ${type}`
    element.style.display = "block"
  
    // Hide message after 5 seconds for success messages
    if (type === "success") {
      setTimeout(() => {
        element.style.display = "none"
      }, 5000)
    }
  }
  
  /**
   * Validate Email
   */
  function validateEmail(email) {
    const re =
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    return re.test(String(email).toLowerCase())
  }
  
  /**
   * Validate Phone
   */
  function validatePhone(phone) {
    // Simple validation for demo purposes
    // In a real application, you would use a more robust validation
    return phone.length >= 10
  }
  