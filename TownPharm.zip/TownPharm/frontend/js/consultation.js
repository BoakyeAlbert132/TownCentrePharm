/**
 * Town Centre Pharmacy - Consultation JavaScript
 * Author: Town Centre Pharmacy
 * Version: 1.0
 */

document.addEventListener("DOMContentLoaded", () => {
    // Initialize appointment form
    initAppointmentForm()
  })
  
  /**
   * Initialize Appointment Form
   */
  function initAppointmentForm() {
    const appointmentForm = document.getElementById("appointment-form")
    const appointmentMessage = document.getElementById("appointment-message")
  
    if (!appointmentForm || !appointmentMessage) return
  
    appointmentForm.addEventListener("submit", function (e) {
      e.preventDefault()
  
      // Get form data
      const name = this.querySelector("#name").value
      const email = this.querySelector("#email").value
      const phone = this.querySelector("#phone").value
      const consultationType = this.querySelector("#consultation-type").value
      const date = this.querySelector("#date").value
      const time = this.querySelector("#time").value
      const reason = this.querySelector("#reason").value
      const medicalHistory = this.querySelector("#medical-history").value
      const terms = this.querySelector("#terms")?.checked || false
  
      // Validate form data
      if (!name || !email || !phone || !consultationType || !date || !time || !reason) {
        showMessage(appointmentMessage, "Please fill in all required fields.", "error")
        return
      }
  
      if (!validateEmail(email)) {
        showMessage(appointmentMessage, "Please enter a valid email address.", "error")
        return
      }
  
      if (!validatePhone(phone)) {
        showMessage(appointmentMessage, "Please enter a valid phone number.", "error")
        return
      }
  
      if (!terms) {
        showMessage(appointmentMessage, "Please agree to the Terms and Conditions.", "error")
        return
      }
  
      // Validate date and time
      const selectedDateTime = new Date(`${date}T${time}`)
      const now = new Date()
  
      if (selectedDateTime <= now) {
        showMessage(appointmentMessage, "Please select a future date and time.", "error")
        return
      }
  
      // Show loading message
      showMessage(appointmentMessage, "Submitting your appointment request...", "info")
  
      // Simulate API call with timeout
      setTimeout(() => {
        // In a real application, you would send this data to your server
        console.log("Appointment request:", {
          name,
          email,
          phone,
          consultationType,
          date,
          time,
          reason,
          medicalHistory,
          terms,
        })
  
        // Show success message
        showMessage(
          appointmentMessage,
          "Your appointment request has been submitted successfully! We will contact you shortly to confirm your appointment.",
          "success",
        )
  
        // Reset form
        appointmentForm.reset()
      }, 1500)
    })
  }
  
  /**
   * Show Message
   */
  function showMessage(element, text, type) {
    element.textContent = text
    element.className = `form-message ${type}`
    element.style.display = "block"
  
    // Scroll to message
    element.scrollIntoView({ behavior: "smooth", block: "center" })
  
    // Hide message after 5 seconds for success messages
    if (type === "success") {
      setTimeout(() => {
        element.style.display = "none"
      }, 5000)
    }
  }
  
  /**
   * Validate Email
   */
  function validateEmail(email) {
    const re =
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    return re.test(String(email).toLowerCase())
  }
  
  /**
   * Validate Phone
   */
  function validatePhone(phone) {
    // Simple validation for demo purposes
    // In a real application, you would use a more robust validation
    return phone.length >= 10
  }
  